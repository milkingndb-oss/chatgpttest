---
name: transcript-to-video-production
description: Convert long story transcripts into complete narration-video production packages. Use when Codex is asked to process a transcript, normalize character names/forms, generate character profile specs, rewrite the story for narration, create a location bible, build a micro/atomic scene breakdown for image generation, audit profile links and plot consistency, or continue a transcript-to-video image pipeline.
---

# Transcript To Video Production

## Purpose

Turn a transcript into a production-ready story-video package: character bible, visual style, character/profile image plan, rewritten narration story, location bible, atomic scene breakdown, validation reports, and optional scene-image generation workflow.

This skill is designed for long-form fantasy/action recap, progression, cultivation, game-system, dungeon, monster, academy, military, or similar narration videos, but the workflow also works for other serialized story transcripts.

## Core Workflow

Follow these phases in order unless the user explicitly asks for only one artifact.

1. **Collect inputs**
   - Ask for the transcript or transcript file path.
   - Ask for the visual style before generating profile images.
   - Ask for target runtime or word count if not provided.
   - Ask whether to create an original continuation if the transcript is incomplete.
   - Ask where to save outputs if the user wants a non-default location.

2. **Extract and normalize**
   - Extract transcript text from PDF/DOCX/TXT/MD when needed.
   - Identify plot arcs, major locations, factions, powers, items, stat systems, bosses, and character forms.
   - Group misspellings and aliases under canonical names.
   - Create `character-bible.json` or `character-bible.md`.

3. **Create visual production rules**
   - Ask for or infer visual style only after asking if style is missing.
   - Define aspect ratio, series style, palette, profile-sheet layout, stat-card style, and image-generation constraints.
   - Create `visual-style-guide.md` if useful.

4. **Create character profile plan or images**
   - For every canonical character/form, create a profile spec or generate a profile sheet.
   - Required profile sheet views: front, side, back, 3/4 pose, face closeup, outfit/material details, weapon/details when relevant.
   - Create separate profiles for major forms, evolutions, adult/child forms, armor states, divine states, monster stages, corruption states, and size/silhouette changes.
   - Use deterministic filenames. See `references/schemas.md`.

5. **Rewrite the transcript**
   - Rephrase into original narration prose while preserving the same plot, characters, forms, factions, powers, and major beats.
   - Do not copy long passages line-by-line.
   - Build a strong first-five-minute hook using future payoff, mystery, betrayal, humiliation, hidden power, or a cliffhanger.
   - If the transcript ends unfinished and the user approved continuation, clearly treat the ending as an original completion.

6. **Create location bible**
   - Define every recurring location with look, lighting, props, mood, visual constraints, and scene IDs.
   - Create `location-bible.md`.

7. **Create scene breakdown**
   - Create `scenebreakdown.json`.
   - Use 16:9 as default image aspect ratio.
   - First 5 minutes: 4-6 second image beats with maximum hook value.
   - First 10 minutes: 4-6 second dense micro-beats.
   - Rest of video: 25-40 second beats, faster for fights/forms/stat moments.
   - Every scene must link required characters to profile image filenames.
   - Mark stat cards for system reveals, ranks, evolutions, form changes, boss reveals, mission screens, scoreboards, and major power upgrades.

8. **Audit and fix**
   - Validate all JSON.
   - Check duplicate scene IDs.
   - Check every scene location exists in the location bible.
   - Check every referenced profile image exists.
   - Check every profile image is used or intentionally marked unused.
   - Check every story character/form is in the character bible.
   - Check the rewrite and scene breakdown represent the same plot in the same order.
   - Patch missing details before final response.

9. **Optional image generation**
   - Generate scene images sequentially from `scenebreakdown.json`.
   - Load/view required character profile images before prompting.
   - Save outputs as `scene_images/scene_###.png`.
   - Keep generated originals and copy final assets into the project.

## Required Artifacts

Use these filenames unless the user requests different names:

- `character-bible.json` or `character-bible.md`
- `visual-style-guide.md`
- `completed-rewritten-narration-story.md`
- `location-bible.md`
- `scenebreakdown.json`
- `scene_images/scene_###.png`
- `PROJECT_HANDOFF_GUIDE.md` when the user asks to migrate or hand off the project

## References

Load these only when needed:

- `references/schemas.md`: exact schemas, filename conventions, and artifact formats.
- `references/prompting.md`: prompt templates for character profiles, scene images, stat cards, and first-five-minute hooks.
- `references/audits.md`: audit checklist and validation commands.

## Scripts

Use `scripts/audit_video_package.py` when a project has a story file, scene breakdown, location bible, and profile images. It validates JSON shape, duplicate scene IDs, missing profile references, unused profile images, and missing location-bible entries.

## Rules

- Preserve the source plot unless the user asks for adaptation or continuation.
- Clearly label original continuation when the source transcript is incomplete.
- Never silently invent major new characters when profile images already exist.
- Do not drop side characters just because they are inconvenient; use them in meaningful scenes or mark them intentionally excluded.
- Do not generate character profiles without visual style guidance unless the user explicitly allows you to infer a style.
- Do not leave scene images only in the generator's default output directory; copy them into the project.
- Do not overwrite generated images unless the user explicitly asks.
