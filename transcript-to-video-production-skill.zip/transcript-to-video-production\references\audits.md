# Audit Checklist

Run an audit after creating or changing each major artifact.

## Story Audit

- Target runtime/word count is satisfied.
- First five minutes have a strong hook.
- Source plot is preserved unless adaptation was requested.
- Any original continuation is clearly identified.
- All canonical characters and forms appear in the character bible.
- Major side characters are not accidentally dropped.
- Misspelled names are normalized.

## Scene Breakdown Audit

- `scenebreakdown.json` parses.
- Scene IDs are unique.
- Required fields exist on every scene.
- First five minutes use 4-6 second beats.
- First ten minutes use 4-6 second beats.
- Remaining scenes use 25-40 second beats or justified exceptions.
- Every required character has `name`, `profileImage`, and `role`.
- Every profile image filename exists in the project.
- Every scene location exists in `location-bible.md`.
- Stat card scenes are marked for forms, evolutions, ranks, bosses, scoreboards, system reveals, mission screens, and major upgrades.

## Location Bible Audit

- Every scene location has an entry.
- Every entry defines purpose, look, lighting, props, mood, and scene IDs.
- Visual rules match the story's genre and style.

## Image Generation Audit

- Generated images are saved in `scene_images/`.
- Filenames are sequential.
- Profile references were loaded or explicitly used in the prompt.
- The scene image matches the scene breakdown.
- Bad generations are versioned rather than overwritten.

## Useful Commands

```powershell
node -e "const fs=require('fs'); const j=JSON.parse(fs.readFileSync('scenebreakdown.json','utf8')); const ids=j.scenes.map(s=>s.id); const dup=ids.filter((id,i)=>ids.indexOf(id)!==i); console.log({sceneCount:j.scenes.length, duplicateIds:dup, statCards:j.scenes.filter(s=>s.statCardRequired).length});"
```

```powershell
py path\to\skill\scripts\audit_video_package.py .
```
