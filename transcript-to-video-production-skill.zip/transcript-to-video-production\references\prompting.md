# Prompting Templates

## First Five Minute Hook Pattern

A strong first five minutes should usually contain:

1. Future payoff or danger image.
2. Main character emotional wound.
3. Public humiliation or betrayal.
4. Hidden power clue.
5. Clear system/talent reveal.
6. Cliffhanger into the first transformation, fight, or reversal.

Keep the plot intact by using the cold open as a flash-forward, then returning to the chronological start.

## Character Profile Prompt

```text
Use case: illustration-story
Asset type: character profile sheet
Primary request: Create a full character profile sheet for <canonical name>, <form name>.
Scene/backdrop: clean white or light neutral reference-sheet background.
Subject: <character description, role, age/stage, outfit, powers, weapons, aura>.
Style/medium: <visual style chosen by user>, production-ready reference sheet.
Composition/framing: front pose, side pose, back pose, 3/4 pose, face closeup, outfit/material detail crops, weapon/aura/detail crops where relevant.
Lighting/mood: clean studio lighting, readable silhouette.
Color palette: <series palette and character-specific colors>.
Text: optional short label only if requested.
Constraints: keep sheet clean; no random extra characters; no watermark; no cluttered background.
```

## Scene Image Prompt

```text
Use case: illustration-story
Asset type: 16:9 cinematic scene image for scene <ID>
Primary request: <title and storyMoment>
Input images used as character reference: <profile filename list and what to preserve>
Scene/backdrop: <location + location bible details>
Subject: <main visual action>
Style/medium: high-end anime fantasy key visual, cinematic painterly concept art
Composition/framing: <cameraViewType>
Lighting/mood: <mood>
Color palette: <palette>
Constraints: preserve character designs from profile references; no text, no watermark, no labels, no UI overlays unless stat-card scene requires it.
```

## Stat Card Prompt Add-On

Use for system/talent/evolution scenes:

```text
Add a clean translucent blue-black fantasy system interface near the subject.
Keep text minimal and readable. Prefer symbolic stat blocks if exact wording is not required.
Do not cover faces, action, or important silhouettes.
```

## Rewrite Prompt Pattern

```text
Rewrite the transcript as original narration prose for a <target runtime> story video.
Preserve the same plot, characters, forms, powers, factions, and major beats.
Normalize misspelled names according to the character bible.
Open with a strong first-five-minute hook, then return to chronological story flow.
Do not copy long source passages line-by-line.
If the transcript is incomplete and continuation is approved, clearly create an original ending consistent with the setup.
```
