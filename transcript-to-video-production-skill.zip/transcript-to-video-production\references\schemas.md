# Schemas And Conventions

## Character Bible Schema

Use JSON for automation-heavy projects and Markdown for writer-facing projects.

```json
{
  "canonicalName": "Hey Ming",
  "aliases": ["Hay Ming", "Haying", "Haing", "Heiming"],
  "type": "summoned beast",
  "role": "Chenlin's lifebound devouring wolf",
  "relationships": ["lifebound to Chenlin"],
  "forms": [
    {
      "formId": "HM-F0",
      "formName": "tiny puppy form",
      "profileImage": "Hey_Ming_HM-F0.png",
      "firstAppearance": "awakening ceremony",
      "visualNotes": "tiny black puppy, loyal eyes",
      "powerNotes": "hidden Gluttonous Greed not publicly visible"
    }
  ],
  "continuityNotes": "Always normalize misspellings to Hey Ming."
}
```

## Profile Filename Convention

Use stable, sortable filenames:

- Human progression form: `Chenlin_CL-F0.png`, `Chenlin_CL-F1.png`
- Summoned beast form: `Hey_Ming_HM-F0.png`
- Named form variants: `Diana_DI-F4.png`
- Enemy group variants: `Fallen_Clan_FC-F1.png`
- Single-profile character: `Lu_Ru_Yan.png`

Use underscores, not spaces. Keep the exact filename in all scene references.

## Character Profile Sheet Requirements

Every generated profile sheet should include:

- front pose
- side pose
- back pose
- 3/4 pose
- face closeup
- outfit/material detail crops
- weapon, wings, claws, armor, aura, or item details when relevant
- form label if text is acceptable

Generate a new profile when any of these changes:

- age or body stage
- evolution/form
- armor state
- monster size/silhouette
- divine/corrupted/fallen state
- weapon set
- identity-critical outfit

## Scene Breakdown Schema

`scenebreakdown.json` should contain:

```json
{
  "project": "Project title",
  "sceneGranularity": "atomic_with_dense_opening",
  "firstFiveMinutes": {
    "imageBeatCadenceSeconds": "4-6",
    "atomicSceneRange": "F5_001-F5_060",
    "atomicSceneCount": 60
  },
  "firstTenMinutes": {
    "imageBeatCadenceSeconds": "4-6",
    "atomicSceneRanges": ["F5_001-F5_060", "T10_061-T10_120"],
    "atomicSceneCount": 120
  },
  "scenes": [
    {
      "id": "F5_001",
      "title": "Cold Open: No One Laughs Later",
      "storyMoment": "Hey Ming towers over Wooan as armies burn below.",
      "location": "Wooan Mountain Battlefield",
      "cameraViewType": "future-scale battle wide shot",
      "requiredCharacters": [
        {
          "name": "Chenlin",
          "profileImage": "Chenlin_CL-F4.png",
          "role": "future battlefield hero"
        }
      ],
      "statCardRequired": true,
      "statCardReason": "Immediate future payoff.",
      "imagePromptNotes": "First 5 minutes: 4-6 second hook cadence."
    }
  ]
}
```

## Location Bible Entry

Each location should include:

```markdown
## Location Name

- **Purpose**:
- **Look**:
- **Lighting**:
- **Recurring props**:
- **Mood**:
- **Avoid**:
- **Scene IDs**:
```

## Output Folder Convention

Use:

```text
scene_images/
  scene_001.png
  scene_002.png
  scene_003.png
```

For regeneration:

```text
scene_003_v2.png
```
