#!/usr/bin/env python3
"""Audit a transcript-to-video production package."""

from __future__ import annotations

import json
import sys
from pathlib import Path


def fail(message: str) -> None:
    print(f"[FAIL] {message}")


def ok(message: str) -> None:
    print(f"[OK] {message}")


def main() -> int:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    scene_path = root / "scenebreakdown.json"
    bible_path = root / "location-bible.md"

    errors: list[str] = []

    if not scene_path.exists():
        errors.append("Missing scenebreakdown.json")
    if not bible_path.exists():
        errors.append("Missing location-bible.md")

    if errors:
        for error in errors:
            fail(error)
        return 1

    try:
        data = json.loads(scene_path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        fail(f"Could not parse scenebreakdown.json: {exc}")
        return 1

    scenes = data.get("scenes")
    if not isinstance(scenes, list) or not scenes:
        fail("scenebreakdown.json has no scenes array")
        return 1

    ids = [scene.get("id") for scene in scenes]
    duplicates = sorted({scene_id for scene_id in ids if ids.count(scene_id) > 1})
    if duplicates:
        errors.append(f"Duplicate scene IDs: {duplicates}")

    required_scene_fields = {
        "id",
        "title",
        "storyMoment",
        "location",
        "cameraViewType",
        "requiredCharacters",
        "statCardRequired",
        "statCardReason",
        "imagePromptNotes",
    }

    profile_refs: set[str] = set()
    png_files = {path.name for path in root.glob("*.png")}

    for index, scene in enumerate(scenes):
        scene_id = scene.get("id", f"index-{index}")
        missing_fields = sorted(required_scene_fields - set(scene))
        if missing_fields:
            errors.append(f"{scene_id}: missing fields {missing_fields}")
        chars = scene.get("requiredCharacters")
        if not isinstance(chars, list) or not chars:
            errors.append(f"{scene_id}: requiredCharacters is empty or invalid")
            continue
        for char in chars:
            for field in ("name", "profileImage", "role"):
                if not char.get(field):
                    errors.append(f"{scene_id}: incomplete character object {char}")
            profile = char.get("profileImage")
            if profile:
                profile_refs.add(profile)
                if profile not in png_files:
                    errors.append(f"{scene_id}: missing profile image {profile}")

    unused_pngs = sorted(png_files - profile_refs)
    if unused_pngs:
        errors.append(f"Unused PNG files: {unused_pngs}")

    bible = bible_path.read_text(encoding="utf-8")
    headings = {
        line[3:].strip()
        for line in bible.splitlines()
        if line.startswith("## ")
    }
    scene_locations = {scene.get("location") for scene in scenes if scene.get("location")}
    missing_locations = sorted(scene_locations - headings)
    if missing_locations:
        errors.append(f"Locations missing from location bible: {missing_locations}")

    if errors:
        for error in errors:
            fail(error)
        return 1

    ok(f"Scenes: {len(scenes)}")
    ok(f"Profile images referenced: {len(profile_refs)}")
    ok(f"Locations referenced: {len(scene_locations)}")
    ok("Scene breakdown, profile links, and location bible are consistent")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
